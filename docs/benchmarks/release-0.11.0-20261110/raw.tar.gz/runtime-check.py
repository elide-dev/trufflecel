import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
assert (root/'exit-status').read_text().strip()=='0'
manifest=json.loads((root/'source.json').read_text())
meta=json.loads((root/'evaluation/memory/metadata.json').read_text())
expected={'bin/java':meta['sha256']['java'],**meta['runtime_sha256']}
archive=root/'toolchain/graalvm.tar.gz'
with archive.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
assert digest==manifest['graalvm_archive_sha256']
observed={}
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  for name in expected:
   if member.name.endswith('/'+name):
    assert name not in observed
    with tar.extractfile(member) as stream:observed[name]=hashlib.file_digest(stream,'sha256').hexdigest()
assert observed==expected,(observed,expected)
(root/'runtime-verification.json').write_text(json.dumps({'archive_sha256':digest,'members':observed,'matches_measured_runtime':True},indent=2)+'\n')
print('Measured Java executable, release metadata, modules and libjvm match the pinned archive.')
