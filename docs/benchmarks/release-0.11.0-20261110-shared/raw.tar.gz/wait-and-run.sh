#!/usr/bin/env bash
set -euo pipefail
cd /home/sam/trufflecel-release-011-20261110
while kill -0 818783 2>/dev/null; do
  printf '%s waiting for existing Myna benchmark PID 818783\n' "$(date -u +%FT%TZ)"
  sleep 15
done
printf '%s existing workload ended; allowing 30 seconds idle\n' "$(date -u +%FT%TZ)"
sleep 30
if pgrep -x ffm-aot >/dev/null; then
  echo 'Another FFM workload is active; measurement not started.'
  exit 1
fi
uptime
exec bash run.sh
