"""Wait for other compute jobs; abort our entire round if one appears mid-run."""
import datetime,json,os,signal,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
os.chdir(root)
(root/"guard.pid").write_text(str(os.getpid())+"\n")
watch={'elide','ffm-aot','native-image','rustc','cargo','clang','clang++','cc1','cc1plus','javac','ninja'}
def snapshot(own_session=None):
 rows=[]
 output=subprocess.check_output(['ps','-eo','pid=,ppid=,sid=,comm=,pcpu=,etimes='],text=True)
 for line in output.splitlines():
  pid,parent,session,comm,cpu,age=line.split()
  if int(session)==own_session or int(pid)==os.getpid() or int(parent)==os.getpid():continue
  if int(session)==1495924 or comm in watch or (float(cpu)>20 and int(age)>=5):
   rows.append(dict(pid=int(pid),parent=int(parent),session=int(session),command=comm,cpu_percent=float(cpu)))
 record=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),load=os.getloadavg(),stage="measurement" if own_session is not None else "waiting",external_work=rows)
 with (root/'host-monitor.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 return record
quiet_since=None
while True:
 record=snapshot()
 if record['external_work']:
  quiet_since=None
  print(record['time'],'waiting for other compute work:',[(p['pid'],p['command']) for p in record['external_work']],flush=True)
 else:
  if quiet_since is None:quiet_since=time.monotonic()
  if time.monotonic()-quiet_since>=180:break
 time.sleep(5)
print('Starting full guarded round after 180 seconds without detected competing compute work.',flush=True)
started_at=datetime.datetime.now(datetime.timezone.utc).isoformat()
child=subprocess.Popen(['bash','run.sh'],start_new_session=True)
(root/'guard-status.json').write_text(json.dumps(dict(status='running',started_at=started_at))+'\n')
while child.poll() is None:
 time.sleep(5)
 if child.poll() is not None:break
 record=snapshot(child.pid)
 if record['external_work']:
  print('Competing compute work appeared; terminating only our round and retaining all records.',flush=True)
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
  (root/'guard-status.json').write_text(json.dumps(dict(status='aborted-for-interference',observation=record),indent=2)+'\n')
  raise SystemExit(2)
(root/'guard-status.json').write_text(json.dumps(dict(status='complete' if child.returncode==0 else 'failed',exit_code=child.returncode,started_at=started_at,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(child.returncode)
