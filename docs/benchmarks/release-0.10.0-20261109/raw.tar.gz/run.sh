#!/usr/bin/env bash
set -euo pipefail
bench_root=/home/sam/trufflecel-release-010-20261109
bench_java=/home/sam/trufflecel-010-bench-20261108/toolchain/graalvm-ce-25.5.5-elide.27-linux-amd64/bin/java
bench_lock=/tmp/trufflecel-010-remote-measurement.lock
mkdir "$bench_lock"
trap 'rmdir "$bench_lock"' EXIT
cd "$bench_root"
date -u > started.txt
for suite in evaluation prepared-inputs; do
  driver=tools/evaluation_refresh.py
  if [[ "$suite" == prepared-inputs ]]; then driver=tools/cel_java_inputs.py; fi
  for phase in memory jvm-timing native-timing; do
    python3 "$driver" "$phase" --java "$bench_java" \
      --jmh "$bench_root/jmh.jar" --memory-jar "$bench_root/memory.jar" \
      --native "$bench_root/timing-native" --memory-native "$bench_root/memory-native" \
      --source-manifest source.json --cpus 2,3,4,5,6,7,8,9 --output "$suite/$phase"
  done
done
mkdir ingestion
sha256sum ingestion.jar ingestion-native > ingestion/artifacts.sha256
for fork in 0 1 2; do
  for fixture in ordinary unknown64k messageset; do
    taskset -c 2-9 "$bench_java" -XX:-UseJVMCICompiler -Xbatch -Xms512m -Xmx512m --enable-native-access=ALL-UNNAMED -Dpolyglot.engine.Compilation=false -jar ingestion.jar allocate "$fixture" > "ingestion/jvm-$fixture-$fork.jsonl" 2> "ingestion/jvm-$fixture-$fork.stderr"
    taskset -c 2-9 ./ingestion-native -Xms512m -Xmx512m "$fixture" > "ingestion/svm-$fixture-$fork.jsonl" 2> "ingestion/svm-$fixture-$fork.stderr"
  done
done
date -u > completed.txt
