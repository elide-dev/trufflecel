#!/usr/bin/env bash
set -euo pipefail
cd /home/sam/trufflecel-010-bench-20261108/comparison
lock=/tmp/trufflecel-010-remote-measurement.lock
mkdir "$lock"
trap 'rmdir "$lock"' EXIT
java_path=/home/sam/trufflecel-010-bench-20261108/toolchain/graalvm-ce-25.5.5-elide.27-linux-amd64/bin/java
for phase in memory jvm-timing native-timing; do
  python3 evaluation_refresh.py "$phase" --java "$java_path" --jmh jmh_deploy.jar --memory-jar evaluation_memory_deploy.jar --native representative --memory-native evaluation-memory --source-manifest trufflecel-010-comparison-source.json --output "$phase" --cpus 2,3,4,5,6,7,8,9
done
